void * readFile(void *);
void * formatText(void *);
void * writeText(void *);
void formatter(int location, int locationJ, int row);